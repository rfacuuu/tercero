param([string]$Root='C:\Users\Facu\tercero-nuevo-20261104-152331',[string]$FeedFolder='')
$ErrorActionPreference='Stop'
$changed=$false
$target=Join-Path $Root 'app\resources\app.asar'
try {
 if(!(Test-Path -LiteralPath (Join-Path $Root 'app\tercero.exe')) -or !(Test-Path -LiteralPath $target)){throw 'No se encontro la instalacion actual. No se creo otra carpeta. Conserva esta ventana para revisar la ruta.'}
 if(!$FeedFolder){
  Add-Type -AssemblyName System.Windows.Forms
  $picker=New-Object System.Windows.Forms.FolderBrowserDialog
  $picker.Description='Elegi la carpeta Tercero actualizaciones de tu Google Drive (no la carpeta del ZIP descargado)'
  $picker.ShowNewFolderButton=$false
  if($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){throw 'Configuracion cancelada. No se cambio la app.'}
  $FeedFolder=$picker.SelectedPath
 }
 if(!(Test-Path -LiteralPath (Join-Path $FeedFolder 'tercero-ultima.json'))){throw 'La carpeta elegida no contiene tercero-ultima.json. Espera la sincronizacion de Drive y elegi la carpeta de actualizaciones.'}
 $r=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'tercero-release-0.2.1.json') -Raw|ConvertFrom-Json
 $bytes=[Convert]::FromBase64String($r.asar)
 $sha=[Security.Cryptography.SHA256]::Create()
 $h=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()
 if($h -ne $r.sha256 -or $r.format -ne 'tercero-release-1'){throw 'Paquete incompleto o alterado. No se cambio la app.'}
 function PackageVersion([byte[]]$b) {
  if($b.Length -lt 16){throw 'ASAR incompleto.'}
  $h=[BitConverter]::ToUInt32($b,12)
  if($h -gt 1048576 -or (16+$h) -gt $b.Length){throw 'Cabecera invalida.'}
  $j=[Text.Encoding]::UTF8.GetString($b,16,$h)|ConvertFrom-Json
  $p=$j.files.'package.json';if(!$p){throw 'Falta package.json.'}
  $o=8+[BitConverter]::ToUInt32($b,4)+[int]$p.offset
  if($p.size -gt 1048576 -or ($o+$p.size) -gt $b.Length){throw 'Paquete invalido.'}
  return ([Text.Encoding]::UTF8.GetString($b,$o,[int]$p.size)|ConvertFrom-Json).version
 }
 if((PackageVersion $bytes) -ne $r.version){throw 'Version de release inconsistente.'}
 if([version]$r.version -lt [version](PackageVersion ([IO.File]::ReadAllBytes($target)))){throw 'La app instalada es mas nueva. No se reemplaza.'}
 $running=Get-Process -Name tercero -ErrorAction SilentlyContinue|Where-Object {$_.Path -eq (Join-Path $Root 'app\tercero.exe')}
 if($running){throw 'Antes de preparar, guarda tus campos pendientes y cerra Tercero con Salir desde el tray. Luego volve a abrir PREPARAR.cmd.'}
 Copy-Item -LiteralPath $target -Destination ($target+'.antes-drive.bak') -Force
 $changed=$true
 [IO.File]::WriteAllBytes($target,$bytes)
 if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $h){throw 'No coincidio la copia.'}
 @{channel='drive-folder';folder=$FeedFolder}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Root 'actualizaciones.json') -Encoding UTF8
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'tray-update-local.ps1') -Destination (Join-Path $Root 'tray-update-local.ps1') -Force
 $cmd="@echo off`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0tray-update-local.ps1`" -Root `"%~dp0.`"`r`n"
 [IO.File]::WriteAllText((Join-Path $Root 'ACTUALIZAR-LOCAL.cmd'),$cmd)
 Write-Host 'Preparado en la MISMA instalacion. Preferencias y notas no se tocaron.'
 Start-Process -FilePath (Join-Path $Root 'app\tercero.exe') -WorkingDirectory (Join-Path $Root 'app')
 Write-Host 'Apertura solicitada. Confirma v0.2.1 visible y el icono en la bandeja.'
} catch {
 if($changed){try{Copy-Item -LiteralPath ($target+'.antes-drive.bak') -Destination $target -Force;Write-Host 'Se restauro la app anterior.'}catch{Write-Host 'No se pudo restaurar. Conserva el backup .antes-drive.bak.'}}
 Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red
}
Read-Host 'Presiona Enter para cerrar'
